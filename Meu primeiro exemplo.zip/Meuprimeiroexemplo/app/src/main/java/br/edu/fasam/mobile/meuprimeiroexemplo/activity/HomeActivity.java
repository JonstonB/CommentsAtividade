package br.edu.fasam.mobile.meuprimeiroexemplo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import br.edu.fasam.mobile.meuprimeiroexemplo.R;
import br.edu.fasam.mobile.meuprimeiroexemplo.debug.DebugActivity;

public class HomeActivity extends DebugActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
    public void Exibir (View view) {
        int opcao = view.getId();
        Intent intent = new Intent();

        switch (opcao) {
            case R.id.btnAddress:

                intent = new Intent(this, AddressActivity.class);
                startActivity(intent);

                break;
            case R.id.btnPessoa:

                intent = new Intent(this, PessoaActivity.class);
                startActivity(intent);

                break;
            case R.id.btnUser:

                intent = new Intent(this, UserActivity.class);
                startActivity(intent);

                break;
            case R.id.btnPost:
            case R.id.btnComments1:

                intent = new Intent(this, CommentsActivity.class);
                startActivity(intent);

                break;

            default:
                Toast.makeText(this,"Opção Inválida.", Toast.LENGTH_LONG).show();
                break;
        }

    }



}