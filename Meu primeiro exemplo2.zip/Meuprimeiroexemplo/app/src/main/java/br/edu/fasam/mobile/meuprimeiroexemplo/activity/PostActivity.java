package br.edu.fasam.mobile.meuprimeiroexemplo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.edu.fasam.mobile.meuprimeiroexemplo.R;
import br.edu.fasam.mobile.meuprimeiroexemplo.debug.DebugActivity;

public class PostActivity extends DebugActivity {

    EditText txtUserId;
    EditText txtTitle;
    EditText txtBody;
    ListView listViewPost;

    List<HashMap<String, String>> lista = new ArrayList<>(); //Pega a lista de dados enviada pelo usuário

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);
    }

    public void adicionarPost(View view) {

        //ENTRADA
        txtUserId = findViewById(R.id.txtUserId);
        txtTitle = findViewById(R.id.txtTitle);
        txtBody = findViewById(R.id.txtBody);

        //PROCESSAMENTO
        String userId, title, body;
        userId = txtUserId.getText().toString();
        title = txtTitle.getText().toString();
        body = txtBody.getText().toString();

        //AGORA VAMOS INICIAR OS TRABALHOS PARA O SimpleAdapter
        //SimpleAdapter PRECISA DE UM LINK<? EXTENDS HasMap<String, ?>>
        /*
        List<String> bla = new ArrayList<>(); //List trabalha com indice numerico
        bla.add(""); //0
        bla.add(""); //1
        bla.add(""); //2
        bla.add(""); //3
        bla.add(""); //4

        HashMap<String, String> mapExemplo= new HashMap<>(); //HashMap trabalha com indice 'associativo', geralmente
        mapExemplo.put("Index 1", "Valor 1");
        mapExemplo.put("Index 2", "Valor 2");
        mapExemplo.put("Index 3", "Valor 3");
        mapExemplo.put("Index 4", "Valor 4");

        mapExemplo.get("index 3");
       */

        HashMap<String, String> map = new HashMap<>(); //Armazena as informações do usuário num MAP (Mapa de Valores)
        map.put("userId", userId);
        map.put("title",title);
        map.put("body", body);

        lista.add(map);
        //SimpleAdapter (Context, context, List<? extends Map<String, ?>>, data
        // int resource, String[], from, int[] to)
        //Mapear o layout do tipo "item" com os dados contidos do List<HashMap<String, String>>

        //SAIDA
        String[] from = {"userId", "title", "body"}; //chaves do seu Map
        int[] to = {R.id.txtItemUserId, R.id.txtItemTitle, R.id.txtItemBody}; //ids do layout do tipo "item"

        SimpleAdapter simpleAdapter = new SimpleAdapter(this, lista, R.layout.item_post, from, to);

        //Procurar a referencia da ListView para que essa possa imprimir os dados utilizando o padrão ADAPTER

        listViewPost = findViewById(R.id.ListViewPost);
        listViewPost.setAdapter(simpleAdapter);
    }
}