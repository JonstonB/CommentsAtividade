package br.edu.fasam.mobile.meuprimeiroexemplo.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.edu.fasam.mobile.meuprimeiroexemplo.R;
import br.edu.fasam.mobile.meuprimeiroexemplo.debug.DebugActivity;

public class CommentsActivity extends DebugActivity {

    EditText txtPostId1;
    EditText txtNome1;
    EditText txtEmail1;
    EditText txtBody1;
    ListView listViewComments1;

    List<HashMap<String, String>> lista1 = new ArrayList<>(); //Pega a lista de dados enviada pelo usuário

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);
    }

    public void AdicionarComments(View view) {

        //ENTRADA
        txtPostId1 = findViewById(R.id.txtPostId1);
        txtNome1 = findViewById(R.id.txtNome1);
        txtEmail1 = findViewById(R.id.txtEmail1);
        txtBody1 = findViewById(R.id.txtBody1);


        //PROCESSAMENTO
        String postId, nome, email, body;
        postId = txtPostId1.getText().toString();
        nome = txtNome1.getText().toString();
        email = txtEmail1.getText().toString();
        body = txtBody1.getText().toString();

        HashMap<String, String> map = new HashMap<>(); //Armazena as informações do usuário num MAP (Mapa de Valores)
        map.put("postId", postId);
        map.put("nome", nome);
        map.put("email", email);
        map.put("body", body);

        lista1.add(map);
        //SimpleAdapter (Context, context, List<? extends Map<String, ?>>, data
        // int resource, String[], from, int[] to)
        //Mapear o layout do tipo "item" com os dados contidos do List<HashMap<String, String>>

        //SAIDA
        String[] from = {"userId", "nome", "email", "body"}; //chaves do seu Map
        int[] to = {R.id.txtItemPostId1, R.id.txtItemNome1, R.id.txtItemEmail1, R.id.txtItemBody1}; //ids do layout do tipo "item"

        SimpleAdapter simpleAdapter = new SimpleAdapter(this, lista1, R.layout.item_comments, from, to);

        //Procurar a referencia da ListView para que essa possa imprimir os dados utilizando o padrão ADAPTER

        listViewComments1 = findViewById(R.id.ListViewComments1);
        listViewComments1.setAdapter(simpleAdapter);

        String dados;

        dados = String.format("Comments Adicionado");

        Toast.makeText(getApplicationContext(), dados, Toast.LENGTH_SHORT).show();

    }
}
