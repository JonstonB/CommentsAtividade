package br.edu.fasam.mobile.meuprimeiroexemplo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import br.edu.fasam.mobile.meuprimeiroexemplo.R;
import br.edu.fasam.mobile.meuprimeiroexemplo.debug.DebugActivity;

public class PessoaActivity extends DebugActivity {

    EditText txtNome;
    EditText txtSobrenome;
    EditText editTextTextEmailAddress;
    EditText editTextPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pessoa);
    }

    public void Exibir(View view) {

        txtNome = findViewById(R.id.txtNome);
        txtSobrenome = findViewById(R.id.txtSobrenome);
        editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress);
        editTextPhone = findViewById(R.id.editTextPhone);

        String Nome, SobreNome, email, telefone;
        Nome =  txtNome.getText().toString();
        SobreNome = txtSobrenome.getText().toString();
        email = editTextTextEmailAddress.getText().toString();
        telefone = editTextPhone.getText().toString();

        String dados;

        dados = String.format("Os Valores Informados Foram: \n%s\n%s\n%s\n%s\n", Nome,SobreNome,
                email, telefone);

        Toast.makeText(getApplicationContext(), dados, Toast.LENGTH_SHORT).show();
    }
}